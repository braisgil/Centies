<?php
session_start();

if(isset($_SESSION['login'])){
	$presupuesto = $_SESSION['presupuesto'];
	$restante = $_SESSION['restante'];
	$presupuesto_dia = $_SESSION['presupuesto_dia'];
	$restante_dia = $_SESSION['restante_dia'];
	$usuario = $_SESSION['login'];
	
	if (isset($_GET['knob_selector'])){
		$knob_selector = $_GET['knob_selector'];
	} else {
		$knob_selector = "knob_dia";
	}
//HORAAS CHRV
	if ($knob_selector == "knob_dia"){
		$div = "<div id='resumen'>
					<h3 style='1em'>Te quedan por gastar\n</h3>
					<h1 style='font-size:1.5em'>$restante_dia €</h1>
					<p>Tu presupuesto diario es $presupuesto_dia € <br> Quedan x horas para acabar el día</p>

					<div id='".$knob_selector."'></div>
					<a href='inicio.php?knob_selector=knob_mes' class='button alt'>MES</a>
				</div>";
	} else if ($knob_selector == "knob_mes"){
		$div = "<h3>Tu presupuesto mensual es $presupuesto</h3>";
	}





} else {
	header('location:index.php');
}

?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>No Sidebar - Horizons by TEMPLATED</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <script src="js/jQueryKnob/dist/jquery.knob.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<script>
            $(function($) {

                $(".knob").knob({
                    change : function (value) {
                        //console.log("change : " + value);
                    },
                    release : function (value) {
                        //console.log(this.$.attr('value'));
                        console.log("release : " + value);
                    },
                    cancel : function () {
                        console.log("cancel : ", this);
                    },
                    /*format : function (value) {
                        return value + '%';
                    },*/
                    draw : function () {

                        // "tron" case
                        if(this.$.data('skin') == 'tron') {

                            this.cursorExt = 0.3;

                            var a = this.arc(this.cv)  // Arc
                                , pa                   // Previous arc
                                , r = 1;

                            this.g.lineWidth = this.lineWidth;

                            if (this.o.displayPrevious) {
                                pa = this.arc(this.v);
                                this.g.beginPath();
                                this.g.strokeStyle = this.pColor;
                                this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, pa.s, pa.e, pa.d);
                                this.g.stroke();
                            }

                            this.g.beginPath();
                            this.g.strokeStyle = r ? this.o.fgColor : this.fgColor ;
                            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d);
                            this.g.stroke();

                            this.g.lineWidth = 2;
                            this.g.beginPath();
                            this.g.strokeStyle = this.o.fgColor;
                            this.g.arc( this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
                            this.g.stroke();

                            return false;
                        }
                    }
                });

            });
        </script>
		<script>
			var meses = new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
			var fecha = new Date();
			//document.write(fecha.getDate() + " de " + meses[fecha.getMonth()] + " de " + fecha.getFullYear());
			var diasmes = 0;
			var dia = fecha.getDate();
			var mes = meses[fecha.getMonth()];
			var anio = fecha.getFullYear();
			var hora = fecha.getHours();
			var bisiesto = new Boolean();
			if (anio%4==0){
				bisiesto = true;
			} else {
				bisiesto = false;
			}
			if (mes == "Enero" || mes == "Marzo" || mes == "Mayo" || mes == "Julio" || mes == "Agosto" || mes == "Octubre" || mes == "Diciembre"){
				diasmes = 31;
			} else if (mes == "Febrero" && bisiesto == true) {
				diasmes = 29;
			} else if (mes == "Febrero" && bisiesto != true){
				diasmes = 28;
			} else {
				diasmes = 30;
			}
			var diasrestantes = 0;
			diasrestantes = diasmes - dia;
			diasrestantes = diasrestantes + 1;
			dias_value = diasmes - diasrestantes;
			var horasdia = 24;
			var presupuesto_dia = <?=$presupuesto?> / 30;
			presupuesto_dia = presupuesto_dia.toFixed(2);
		</script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
		</noscript>
		<style>
		#contenedor {
  			width: 320px;
  			margin: 0 auto;
		}

		#knob_dia{
  			/*margin-left: 60px;*/
		}
		#saludo{
			font-size: 1em;
			text-align: center;
		}
		#resumen{
  			text-align: center;
		}

		</style>
	</head>
	<body class="no-sidebar">

		<!-- Header -->
			<div id="header">
				<div class="container">
						
					<!-- Logo -->
						<h1><a href="#" id="logo">Untitled</a></h1>
					
					<!-- Nav -->
						<nav id="nav">
							<ul>
								<li><a href="index.html">Home</a></li>
								<li>
									<a href="">Dropdown</a>
									<ul>
										<li><a href="#">Lorem ipsum dolor</a></li>
										<li><a href="#">Magna phasellus</a></li>
										<li><a href="#">Etiam dolore nisl</a></li>
										<li>
											<a href="">Phasellus consequat</a>
											<ul>
												<li><a href="#">Lorem ipsum dolor</a></li>
												<li><a href="#">Phasellus consequat</a></li>
												<li><a href="#">Magna phasellus</a></li>
												<li><a href="#">Etiam dolore nisl</a></li>
												<li><a href="#">Veroeros feugiat</a></li>
											</ul>
										</li>
										<li><a href="#">Veroeros feugiat</a></li>
									</ul>
								</li>
								<li><a href="left-sidebar.html">Left Sidebar</a></li>
								<li><a href="right-sidebar.html">Right Sidebar</a></li>
								<li><a href="no-sidebar.html">No Sidebar</a></li>
							</ul>
						</nav>

				</div>
			</div>

		<!-- Main -->
			<div id="main" class="wrapper style1">
				<div id="contenedor">
					<section>
						<header class="major">
							<h2 id="saludo">Hola <?=$usuario?></h2>
							<?=$div?>
							
							<!--<input id="knob_mes" class="knob" data-fgColor="chartreuse" data-thickness=".4" data-min="0" data-max="<?=$presupuesto?>" readonly value="<?=$restante?>">-->
							<script type="text/javascript">
							document.getElementById("knob_mes").innerHTML = 
							"<input id='knob_mes' class='knob' data-fgColor='chartreuse' data-thickness='.1' data-min='0' data-max='" + diasmes + "' readonly value='" + dia + "'>";
							</script>
							<script type="text/javascript">
							document.getElementById("knob_dia").innerHTML = 
							"<input id='knob_dia' class='knob' data-fgColor='#3ac984' data-thickness='.1' data-min='0' data-max='24' readonly value='" + hora + "'>";
							</script>
							<!--<a href="inicio.php?knob_selector=knob_dia" class="button alt">DIA</a>-->
							<br/>	
							<a href="logout.php">Logout</a>
						</header>
					</section>
				</div>
			</div>

		<!-- Footer -->
			<div id="footer">
				<div class="container">
					<div class="row">
						<div class="8u">
							<section>
								<header class="major">
									<h2>Centies</h2>
									<span class="byline">Developed by:</br>Brais Vázquez Gil
									</span>
								</header>
								</header>
							</section>
						</div>
						<div class="4u">
							<section>
								<header class="major">
									<h2>Contacto</h2>
									<span class="byline">Para cualquier consulta contacte con nosotros en las siguientes vías.</span>
								</header>
								<ul class="contact">
									<li>
										<span class="mail">Correo</span>
										<span><a href="#">bvgil.developer@gmail.com</a></span>
									</li>
									<li>
										<span class="phone">Página Web</span>
										<span>En construccion</span>
									</li>
								</ul>	
							</section>
						</div>
					</div>

				</div>
			</div>

	</body>
</html>