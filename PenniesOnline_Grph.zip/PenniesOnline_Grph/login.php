<?php
session_start();
require_once('conexion.inc.php');
require_once('login.inc.php');

if (isset($_POST['login']) && isset($_POST['password'])){
//CONSULTA DE LOGIN
$consulta = "SELECT * FROM user WHERE login LIKE '".$_POST['login']."' AND password LIKE md5('".$_POST['password']."')";
$resultado = @mysql_query($consulta);
	if (($resultado != null) && (mysql_num_rows($resultado)>0)) {
				while(($fila = mysql_fetch_assoc($resultado))!=null) {
					$presupuesto 		=		$fila['presupuesto'];
					$restante    		=		$fila['restante'];
					$presupuesto_dia    =		$fila['presupuesto_dia'];
					$restante_dia		=		$fila['restante_dia']; 
				}
				$_SESSION['login'] = $_POST['login'];
				$_SESSION['password'] = $_POST['password'];
				$_SESSION['presupuesto'] = $presupuesto;
				$_SESSION['restante'] = $restante;
				$_SESSION['presupuesto_dia'] = $presupuesto_dia;
				$_SESSION['restante_dia'] = $restante_dia;
				$login = $_SESSION['login'];
				$password = $_SESSION['password'];
				header('location:inicio.php');
	} else {
		echo "no existe";
	}
}

?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Centies - Inicia Sesión</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
		</noscript>
	</head>
	<body class="no-sidebar">

		<!-- Header -->
			<div id="header">
				<div class="container">
						
					<!-- Logo -->
						<h1><a href="#" id="logo">Centies</a></h1>
					
					<!-- Nav -->
						<nav id="nav">
							<ul>
								<li><a href="index.php">Inicio</a></li>
				                <!--<li>
									<a href="">Dropdown</a>
									<ul>
										<li><a href="#">Lorem ipsum dolor</a></li>
										<li><a href="#">Magna phasellus</a></li>
										<li><a href="#">Etiam dolore nisl</a></li>
										<li>
											<a href="">Phasellus consequat</a>
											<ul>
												<li><a href="#">Lorem ipsum dolor</a></li>
												<li><a href="#">Phasellus consequat</a></li>
												<li><a href="#">Magna phasellus</a></li>
												<li><a href="#">Etiam dolore nisl</a></li>
												<li><a href="#">Veroeros feugiat</a></li>
											</ul>
										</li>
										<li><a href="#">Veroeros feugiat</a></li>
									</ul>
								</li> -->
								<li><a href="left-sidebar.html">Regístrate</a></li>
								<li><a href="right-sidebar.html">Right Sidebar</a></li>
								<li><a href="no-sidebar.html">No Sidebar</a></li>
							</ul>
						</nav>

				</div>
			</div>

		<!-- Main -->
			<div id="main" class="wrapper style1">
				<div class="container">
					<section>
						<header class="major">
							<h2>Inicia Sesión</h2>
							<span class="byline">Inicia sesión para acceder a tu cuenta.</span>
						</header>
						<p>
							<form action='index.php' id='login' method='post'>
								<fieldset>
									<label for='login'>Login</label>
									<input type='text' name='login' id='login'/>
									<br/>
									<label for='password'>Password</label>
									<input type='password' name='password' id='password'/>
									<br/>
									<input type='submit' value='inicio'/>
								</fieldset>
							</form>
							<br/>
					    </p>
					</section>
				</div>
			</div>

		<!-- Footer -->
			<div id="footer">
				<div class="container">
					<div class="row">
						<div class="8u">
							<section>
								<header class="major">
									<h2>Centies</h2>
									<span class="byline">Developed by:</br>Brais Vázquez Gil
									</span>
								</header>
								</header>
							</section>
						</div>
						<div class="4u">
							<section>
								<header class="major">
									<h2>Contacto</h2>
									<span class="byline">Para cualquier consulta contacte con nosotros en las siguientes vías.</span>
								</header>
								<ul class="contact">
									<li>
										<span class="mail">Correo</span>
										<span><a href="#">bvgil.developer@gmail.com</a></span>
									</li>
									<li>
										<span class="phone">Página Web</span>
										<span>En construccion</span>
									</li>
								</ul>	
							</section>
						</div>
					</div>

				</div>
			</div>

	</body>
</html>