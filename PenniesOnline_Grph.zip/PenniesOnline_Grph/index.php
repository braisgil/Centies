<?php
session_start();
require_once('conexion.inc.php');
require_once('login.inc.php');

if (isset($_POST['login']) && isset($_POST['password'])){
//CONSULTA DE LOGIN
$consulta = "SELECT * FROM user WHERE login LIKE '".$_POST['login']."' AND password LIKE md5('".$_POST['password']."')";
$resultado = @mysql_query($consulta);
	if (($resultado != null) && (mysql_num_rows($resultado)>0)) {
				while(($fila = mysql_fetch_assoc($resultado))!=null) {
					$presupuesto 		=		$fila['presupuesto'];
					$restante    		=		$fila['restante'];
					$presupuesto_dia    =		$fila['presupuesto_dia'];
					$restante_dia		=		$fila['restante_dia']; 
				}
				$_SESSION['login'] = $_POST['login'];
				$_SESSION['password'] = $_POST['password'];
				$_SESSION['presupuesto'] = $presupuesto;
				$_SESSION['restante'] = $restante;
				$_SESSION['presupuesto_dia'] = $presupuesto_dia;
				$_SESSION['restante_dia'] = $restante_dia;
				$login = $_SESSION['login'];
				$password = $_SESSION['password'];
				header('location:Inicio.php');
	} else {
		echo "no existe";
	}
}

?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Centies</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
		</noscript>
	</head>
	<body class="homepage">

		<!-- Header -->
			<div id="header">
				<div class="container">
						
					<!-- Logo -->
						<h1><a href="#" id="logo">Centies</a></h1>
					
					<!-- Nav -->
						<nav id="nav">
							<ul>
								<li><a href="index.php">Inicio</a></li>
								<!--<li>
									<a href="">Dropdown</a>
									<ul>
										<li><a href="#">Lorem ipsum dolor</a></li>
										<li><a href="#">Magna phasellus</a></li>
										<li><a href="#">Etiam dolore nisl</a></li>
										<li>
											<a href="">Phasellus consequat</a>
											<ul>
												<li><a href="#">Lorem ipsum dolor</a></li>
												<li><a href="#">Phasellus consequat</a></li>
												<li><a href="#">Magna phasellus</a></li>
												<li><a href="#">Etiam dolore nisl</a></li>
												<li><a href="#">Veroeros feugiat</a></li>
											</ul>
										</li>
										<li><a href="#">Veroeros feugiat</a></li>
									</ul>
								</li>-->
								<li><a href="no-sidebar.html">Regístrate</a></li>
								<li><a href="right-sidebar.html">Right Sidebar</a></li>
								<li><a href="no-sidebar.html">No Sidebar</a></li>
							</ul>
						</nav>


					<!-- Banner -->
						<div id="banner">
							<div class="container">
								<section>
									<header class="major">
										<h2>Bienvenido a Centies</h2>
										<span class="byline">Centies es la aplicación que hará que ahorres y gestiones tus gastos (mensuales, semanales y diarios) desde tu ordenador, smartphone o tablet de una manera fácil, segura e intuitiva. </span>
									</header>
									<a href="login.php" class="button alt">Inicia sesión</a>
								</section>			
							</div>
						</div>

				</div>
			</div>

		<!-- Main -->
			<div id="main" class="wrapper style1">
				<section class="container">
					<header class="major">
						<h2>Benefíciate de Centies de la manera más sencilla</h2>
						<span class="byline">Regístrate y benefíciate de:</span>
					</header>
					<div class="row">
					
						<!-- Content -->
							<div class="6u">
								<section>
									<ul class="style">
										<li>
											<span class="fa fa-money"></span>
											<h3>Control de gastos</h3>
											<span>Haz un control eficiente de tus gastos sabiendo en cada momento tanto lo gastado como lo ahorrado.</span>
										</li>
										<li>
											<span class="fa fa-refresh"></span>
											<h3>Actualización a tiempo real</h3>
											<span>Estate siempre al tanto a tiempo real de tus operaciones monetarias con unas listas actualizadas.</span>
										</li>
									</ul>
								</section>
							</div>
                            
							<div class="6u">
								<section>
									<ul class="style">
										<li>
											<span class="fa fa-mobile"></span>
											<h3>Control multiplataforma</h3>
											<span>Gestiona tus cuentas sin que importe cual sea el dispositivo electrónico desde el que interactúes.</span>
										</li>
										<li>
											<span class="fa fa-eur"></span>
											<h3>Completamente gratuito</h3>
											<span>Te agradeceríamos una donación voluntaria pero no te cobraremos nada por el uso de nuestros servicios.</span>
										</li>
									</ul>
								</section>
							</div>

					</div>
				</section>
			</div>

		<!-- Footer -->
			<div id="footer">
				<div class="container">
					<div class="row">
						<div class="8u">
							<section>
								<header class="major">
									<h2>Centies</h2>
									<span class="byline">Developed by:</br>Brais Vázquez Gil
									</span>
								</header>
								</header>
							</section>
						</div>
						<div class="4u">
							<section>
								<header class="major">
									<h2>Contacto</h2>
									<span class="byline">Para cualquier consulta contacte con nosotros en las siguientes vías.</span>
								</header>
								<ul class="contact">
									<li>
										<span class="mail">Correo</span>
										<span><a href="#">bvgil.developer@gmail.com</a></span>
									</li>
									<li>
										<span class="phone">Página Web</span>
										<span>En construccion</span>
									</li>
								</ul>	
							</section>
						</div>
					</div>

				</div>
			</div>

	</body>
</html>